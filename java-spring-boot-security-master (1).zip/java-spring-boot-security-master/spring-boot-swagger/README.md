# Postman & Swagger UI Demo 

Учебный проект для практики c Postman и документацией Swagger.

## Эндпоинты

- `GET /users/{id}` — REST по пути (без авторизации)
- `POST /users` — создать пользователя (JSON)
- `GET /users` — список пользователей (**требует** токен в заголовках)

Изначально в памяти есть пользователи `id=1..4`. Любой иной `id` → `404`.

Ссылка до Swagger UI запущенного проекта – http://localhost:8085/swagger-ui/index.html

## Быстрый старт

### Вариант A: командная строка

Запустите скрипт запуска 

- Windows

```shell
./run.bat
```

- Linux/MacOs

```bash
./run.sh
```

Или соберите проект сами и запустите:

```bash
./mvnw -DskipTests clean package
java -jar target/postman-demo-0.0.1-SNAPSHOT.jar --server.port=8085 --app.access-token=demo-token
```

> Для Windows используйте ./mvnw.cmd

### Вариант B: IntelliJ IDEA

Откройте проект в среде разработки и запустите проект.

## Пример запросов (curl)

```bash
curl -i http://localhost:8085/users/1
curl -i http://localhost:8085/users -H "token: demo-token"
curl -i http://localhost:8085/users -H "Content-Type: application/json" -d '{"name":"Alex","id":5}' 
```
