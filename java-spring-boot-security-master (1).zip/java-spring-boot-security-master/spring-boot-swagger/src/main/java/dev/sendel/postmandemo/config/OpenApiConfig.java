package dev.sendel.postmandemo.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI api() {
        return new OpenAPI()
                .info(new Info()
                        .title("My application")
                        .version("1.0.1")
                        .description("Мое приложение")
                        .contact(new Contact().name("Sendel Dev").url("https://sendel.ru")));
    }
}
