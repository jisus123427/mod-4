package dev.sendel.postmandemo.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Schema(description = "Запрос на создание пользователя")
public record User(
        @NotNull
        @Schema(description = "Уникальный идентификатор", example = "42") Integer id,

        @NotBlank @Size(max = 60)
        @Schema(description = "Отображаемое имя", example = "Ada Lovelace") String name) {
}
