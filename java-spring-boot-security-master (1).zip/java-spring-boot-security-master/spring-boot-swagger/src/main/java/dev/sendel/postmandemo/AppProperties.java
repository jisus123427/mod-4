package dev.sendel.postmandemo;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "app")
@Valid
public record AppProperties(
        @NotNull String accessToken) { }
