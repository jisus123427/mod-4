package dev.sendel.postmandemo.model;

import jakarta.validation.constraints.NotBlank;

public record CreateUserRequest(
    @NotBlank String name,
    Integer id
) { }
