package dev.sendel.postmandemo.web;

import dev.sendel.postmandemo.AppProperties;
import dev.sendel.postmandemo.model.CreateUserRequest;
import dev.sendel.postmandemo.model.User;
import dev.sendel.postmandemo.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/users")
@Validated
public class UserController {

    private final UserService users;
    private final AppProperties props;

    public UserController(UserService users, AppProperties props) {
        this.users = users;
        this.props = props;
    }

    // GET /users/{id} (REST по пути, без авторизации)
    @GetMapping("/{id}")
    public ResponseEntity<User> getByPath(@PathVariable int id) {
        return users.findById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }

    @PostMapping
    @Operation(
            summary = "Создать пользователя",
            description = "Создаёт пользователя"
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "201",
                    description = "Пользователь создан",
                    headers = {
                            @Header(name = "Location",
                                    description = "Абсолютный URI созданного пользователя",
                                    schema = @Schema(type = "string", format = "uri"))
                    },
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = User.class))
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Ошибка валидации",
                    content = @Content(mediaType = "application/problem+json",
                            schema = @Schema(implementation = org.springframework.http.ProblemDetail.class))
            )

    })
    public ResponseEntity<User> create(@Valid @RequestBody CreateUserRequest req) {
        User saved = users.save(new User(req.id(), req.name()));
        return ResponseEntity.created(URI.create("/users/" + saved.id())).body(saved);
    }

    // GET /users
    @GetMapping
    public ResponseEntity<List<User>> list(
            @RequestHeader(value = "token", required = false) String token) {
        if (!isAuthorized(token)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        return ResponseEntity.ok(users.findAll());
    }

    private boolean isAuthorized(String token) {
        String required = props.accessToken();
        if (required == null || required.isBlank()) {
            return false;
        }

        return token.equals(required);
    }


}
