package dev.sendel.postmandemo.service;

import dev.sendel.postmandemo.model.User;
import dev.sendel.postmandemo.repo.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
  private final UserRepository repo;
  public UserService(UserRepository repo) { this.repo = repo; }
  public Optional<User> findById(int id) { return repo.findById(id); }
  public List<User> findAll() { return repo.findAll(); }
  public boolean exists(int id) { return repo.existsById(id); }
  public User save(User u) { return repo.save(u); }
}
