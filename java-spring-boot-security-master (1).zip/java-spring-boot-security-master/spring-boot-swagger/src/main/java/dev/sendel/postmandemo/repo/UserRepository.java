package dev.sendel.postmandemo.repo;

import dev.sendel.postmandemo.model.User;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@Repository
public class UserRepository {
  private final Map<Integer, User> store = new ConcurrentHashMap<>();
  private final AtomicInteger seq = new AtomicInteger();

  public UserRepository() {
    store.put(1, new User(1, "Alice"));
    store.put(2, new User(2, "Bob"));
    store.put(3, new User(3, "Carol"));
    store.put(4, new User(4, "Dave"));
    seq.set(4);
  }

  public Optional<User> findById(int id) { return Optional.ofNullable(store.get(id)); }

  public List<User> findAll() {
    return store.values().stream().sorted(Comparator.comparing(User::id)).toList();
  }

  public boolean existsById(int id) { return store.containsKey(id); }

  public User save(User draft) {
    if (draft.id() == null) {
      int id = seq.incrementAndGet();
      User saved = new User(id, draft.name());
      store.put(id, saved);
      return saved;
    }
    store.put(draft.id(), draft);
    seq.updateAndGet(cur -> Math.max(cur, draft.id()));
    return draft;
  }
}
