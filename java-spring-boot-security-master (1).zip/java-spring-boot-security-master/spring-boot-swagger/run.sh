#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

JAR="target/postman-demo-0.0.1-SNAPSHOT.jar"

./mvnw -DskipTests clean package

PORT="${1:-8085}"
TOKEN="${2:-demo-token}"

echo "Запуск на порту ${PORT} с токеном ${TOKEN}"
exec java -jar "$JAR" --server.port="${PORT}" --app.access-token="${TOKEN}"
