@echo off
setlocal enabledelayedexpansion
set JAR=target\postman-demo-0.0.1-SNAPSHOT.jar

./mvnw.cmd -q -DskipTests clean package

set PORT=%1
if "%PORT%"=="" set PORT=8085

set TOKEN=%2
if "%TOKEN%"=="" set TOKEN=demo-token

echo Запуск на порту %PORT% с токеном %TOKEN%
java -jar "%JAR%" --server.port=%PORT% --app.access-token=%TOKEN%
