package ru.coffeepoint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YandexOauthDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(YandexOauthDemoApplication.class, args);
    }
}