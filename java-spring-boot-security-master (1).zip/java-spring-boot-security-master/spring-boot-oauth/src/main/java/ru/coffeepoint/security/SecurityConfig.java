package ru.coffeepoint.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    SecurityFilterChain filterChain(HttpSecurity http, YandexOAuth2UserService yandexOAuth2UserService)
            throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/", "/css/**", "/js/**", "/images/**").permitAll()
                        .anyRequest().authenticated()
                )
                .oauth2Login(oauth -> oauth
                        .loginPage("/oauth2/authorization/yandex")
                        .userInfoEndpoint(userInfo -> userInfo.userService(yandexOAuth2UserService))
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")             // ожидается POST /logout
                        .logoutSuccessUrl("/")            // куда вернуть после выхода
                        .invalidateHttpSession(true)      // инвалидировать сессию
                        .deleteCookies("JSESSIONID")      // (опционально) убрать куку
                );
        return http.build();
    }
}