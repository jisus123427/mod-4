package ru.coffeepoint.security;

import org.springframework.http.MediaType;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.DefaultOAuth2User;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.*;

@Service
public class YandexOAuth2UserService implements OAuth2UserService<OAuth2UserRequest, OAuth2User> {

    private final RestClient rest = RestClient.create();

    @Override
    public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
        var accessToken = userRequest.getAccessToken().getTokenValue();

        @SuppressWarnings("unchecked")
        Map<String, Object> info = rest.get()
                .uri("https://login.yandex.ru/info?format=json")
                .headers(h -> h.set("Authorization", "OAuth " + accessToken))
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .body(Map.class);

        Map<String, Object> attrs = new LinkedHashMap<>();
        if (info != null) {
            attrs.putAll(info);
            attrs.put("name", bestName(info));
            attrs.put("email", info.get("default_email"));
            attrs.put("avatar_url", avatarUrl(info).orElse("null"));
        }

        String nameAttributeKey = "id";
        var authorities = List.of(new SimpleGrantedAuthority("ROLE_USER"));
        return new DefaultOAuth2User(authorities, attrs, nameAttributeKey);
    }

    private Optional<String> avatarUrl(final Map<String, Object> info) {
        String avatarId = toStringOrNull(info.get("default_avatar_id"));
        if (!isBlank(avatarId)) {
            String avatarUrl = "https://avatars.yandex.net/get-yapic/" + avatarId + "/islands-200";
            return Optional.of(avatarUrl);
        }

        return Optional.empty();
    }

    private String bestName(Map<String, Object> info) {
        String name = toStringOrNull(info.get("real_name"));
        if (isBlank(name)) {
            name = toStringOrNull(info.get("display_name"));
        }
        if (isBlank(name)) {
            String first = toStringOrNull(info.get("first_name"));
            String last = toStringOrNull(info.get("last_name"));
            name = ((first != null ? first : "") + " " + (last != null ? last : "")).trim();
        }
        if (isBlank(name)) {
            name = toStringOrNull(info.get("login"));
        }
        return name;
    }

    private static boolean isBlank(String s) {
        return s == null || s.isBlank();
    }

    private static String toStringOrNull(Object o) {
        return o == null ? null : o.toString();
    }
}