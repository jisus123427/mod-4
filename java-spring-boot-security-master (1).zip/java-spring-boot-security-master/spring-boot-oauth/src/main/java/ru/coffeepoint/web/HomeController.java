package ru.coffeepoint.web;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/profile")
    public String profile(@AuthenticationPrincipal OAuth2User user, Model model) {
        model.addAttribute("attrs", user.getAttributes());
        model.addAttribute("name", user.<String>getAttribute("name"));
        model.addAttribute("photo", user.<String>getAttribute("avatar_url"));
        return "profile";
    }
}