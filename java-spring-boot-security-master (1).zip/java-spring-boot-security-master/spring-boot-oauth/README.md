# Yandex OAuth2 + Spring Boot 3 (Java 21) — демо

Рабочий пример входа через **Yandex** с использованием **Spring Security OAuth2 Client**.
Профиль пользователя берём с `https://login.yandex.ru/info` (через заголовок `Authorization: OAuth <token>`).

## Что уже настроено

- Регистрация провайдера `yandex` со следующими эндпоинтами:
  - `authorization-uri`: `https://oauth.yandex.ru/authorize`
  - `token-uri`: `https://oauth.yandex.ru/token`
  - `user-info-uri`: `https://login.yandex.ru/info`
- Запрошенные **permissions/scopes** (должны быть включены в настройках приложения):
  - `login:info`, `login:email`, `login:avatar`

> Redirect URI выставлен шаблоном `{baseUrl}/login/oauth2/code/{registrationId}`.
> Для локальной разработки используем **http://localhost:8080/login/oauth2/code/yandex** — это соответствует
настройке в кабинете Yandex OAuth.

## Требования

- JDK **21**
- Maven **3.9+**
- Созданное приложение в Yandex OAuth с разрешениями (как минимум) Email + Basic profile.
- В настройках платформы — Web, базовый домен `localhost:8080` и Redirect URL:  
  `http://localhost:8080/login/oauth2/code/yandex`

## Переменные окружения

**macOS/Linux (bash/zsh):**
```bash
export YANDEX_CLIENT_ID=your_client_id
export YANDEX_CLIENT_SECRET=your_client_secret
```

**Windows PowerShell:**
```powershell
$env:YANDEX_CLIENT_ID="your_client_id"
$env:YANDEX_CLIENT_SECRET="your_client_secret"
```

## Запуск (вариант 1 — напрямую)

**macOS/Linux (bash/zsh):**
```bash
./mvnw spring-boot:run
```

**Windows PowerShell:**
```bash
mvnw.cmd spring-boot:run
```

Откройте: **http://localhost:8080/**  
Нажмите «Войти через Yandex», пройдите авторизацию и вернитесь в приложение.  
Профиль будет доступен на странице `/profile`.


## Где менять параметры

- `src/main/resources/application.yml` — эндпоинты Yandex OAuth и список `scope`.
- `src/main/java/ru/coffeepoint/security/YandexOAuth2UserService.java` — запрос UserInfo
и сборка атрибутов (`name`, `email`, `avatar_url`).
- `src/main/java/ru/coffeepoint/security/SecurityConfig.java` — правила доступа и включение `oauth2Login`.

## Как это работает (коротко)

1. `/oauth2/authorization/yandex` отправляет пользователя в Yandex OAuth.
2. После согласия пользователь возвращается на `/login/oauth2/code/yandex` с `code`.
3. Бэкенд обменивает `code` на токены на `oauth.yandex.ru/token` (сервер↔сервер).
4. Бэкенд запрашивает `https://login.yandex.ru/info` с `Authorization: OAuth <token>` и формирует профиль.
5. Пользователь видит данные в `/profile`.

## Подсказки и отладка

- Убедитесь, что **Redirect URL** в кабинете **точно** совпадает с тем, что в логах при старте
(`{baseUrl}` = `http://localhost:8080`).
- Если в ответе нет email — проверьте, что у приложения включена permission «Access to email address»
и в запросе есть `login:email`.
- Токены не логируйте. В продакшене используйте HTTPS и храните секреты в ENV / секрет-хранилище.